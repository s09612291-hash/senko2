export default {
 command: "rollwaifu",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  try{const r=await axios.get('https://hikariapi.skyultraweb.com/api/waifu',{timeout:12000});const d=r.data?.result||r.data?.data||r.data;const name=d.name||d.title||'Waifu';const image=d.image||d.url||d.img;if(image)await sock.sendMessage(jid,{image:{url:image},caption:`🎴 ¡Waifu aleatoria!\nNombre: ${name}\nSerie: ${d.serie||d.anime||'Desconocida'}\nValor: ${d.value||100}\nID: ${d.id||name}\nUsa #claim ${d.id||name}`},{quoted:m});else return reply(`🎴 ¡Waifu aleatoria! ${name}`)}catch{return reply('✐ La API de waifus no respondió. Inténtalo más tarde.')} 
 }
};
