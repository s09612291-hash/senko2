export default {
 command: "bots",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const sessions=Object.values(bot.sessions||{});const principals=sessions.filter(s=>s.botType==='Principal').length;const premiums=sessions.filter(s=>s.botType==='Prem Bot').length;const subs=sessions.filter(s=>s.botType==='Sub-Bot').length;const groupMembers=isGroup?(await sock.groupMetadata(jid).catch(()=>({participants:[]}))).participants:[];const mentions=sessions.map(s=>s.jid).filter(Boolean);const botsText=`「✦」Lista de bots activos (${sessions.length} Sesiones)\n❖ Principales » ${principals}\n✰ Premiums » ${premiums}\n✿ Subs » ${subs}\n❏ En este grupo » ${isGroup?groupMembers.length:0}\n\n- Sesiones registradas: ${sessions.length}`;await sock.sendMessage(jid,{text:botsText,mentions:mentions.slice(0,200)},{quoted:m});
 }
};
