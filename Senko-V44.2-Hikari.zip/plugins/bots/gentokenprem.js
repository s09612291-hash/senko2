export default {
 command: "gentokenprem",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  if(!isOwner)return reply('✐ Este comando es exclusivo del owner.');const crypto=await import('node:crypto');const dias=Math.max(1,Math.min(3650,Number(args[0])||30));const token=crypto.randomBytes(4).toString('hex');db.tokens[token]={token,dias,expira:Date.now()+dias*86400000,usado:false,vinculadoA:null};await save();return reply(`✐ TOKEN PREMIUM GENERADO!\n\n✰ *Su token es:* \`${token}\`\n\nPara canjearlo usa:\n✐ #codepremium ${token}\n✐ #qrpremium ${token}\n\n> ⴵ TIEMPO DE EXPIRACIÓN: ${dias} días.`);
 }
};
