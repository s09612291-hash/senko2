export default {
 command: "qrpremium",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const tokenInput=String(args[0]||'').trim().toLowerCase();const supportGroup=bot.supportGroup;if(!tokenInput)return reply('✐ Debes ingresar un token.');const tokenData=db.tokens[tokenInput]||db.settings.tokens?.[tokenInput];if(!tokenData)return reply(`✤ El token \`${tokenInput}\` especificado no se encuentra registrado, verifica que sea correcto y vuelve a intentarlo.\n\n「✿」Si ya tienes un token premium, puedes registrar un sub-bot premium usando los comandos:\n\n*❒ #codepremium [Token]*\n*❒ #qrpremium [Token]*\n\n> ✰ Para obtener un token, contacta con el owner: ${bot.owner}\n\n> Si crees que es un error, escríbenos en el grupo de soporte:\n${supportGroup}`);if(tokenData.expira<=Date.now())return reply(`《✧》 El token \`${tokenInput}\` ya no está activo o ha expirado.\n> Para obtener tu nuevo token contacta con el owner: ${bot.owner}\nOjo: el anterior no vuelve a activarse.\n> Si crees que es un error, escríbenos en el grupo de soporte:\n${supportGroup}`);if(tokenData.usado)return reply(`✐ Ese token ya tiene un bot vinculado: ${tokenData.vinculadoA||'usuario no disponible'}`);return reply('✐ Token válido. La vinculación premium se habilita después de completar el flujo de sesión del sub-bot. Ejecuta #qr para mostrar el QR de vinculación.');
 }
};
