export default {
 command: "botinfo",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  return reply(`╭─ Información Bot\n│ Nombre corto: ${bot.botName}\n│ Nombre: ${bot.botName}\n│ Moneda: ${bot.botCurrency}\n│ Host: SkyUltraPlus / bot-hosting.net\n│ Conectado a: oculto\n│ Tipo: ${bot.botType}\n│ Expiración: ${bot.premExpiration?new Date(bot.premExpiration).toLocaleString():'Permanente'}\n╰─`);
 }
};
