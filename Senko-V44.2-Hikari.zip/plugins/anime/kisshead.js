export default {
 command: "kisshead",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  try{const r=await axios.get('https://hikariapi.skyultraweb.com/api/anime/kisshead',{timeout:12000});const d=r.data?.result||r.data?.data||r.data;const url=typeof d==='string'?d:(d.url||d.image||d.gif||d.video);if(url&&/^https?:/.test(url))return await sock.sendMessage(jid,{image:{url},caption:`✿ kisshead · Senko V44.2`},{quoted:m});return reply('✐ La API no devolvió una imagen compatible.')}catch{return reply('✐ La API de anime no está disponible temporalmente.')}
 }
};
