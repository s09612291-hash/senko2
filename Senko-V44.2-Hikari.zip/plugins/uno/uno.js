export default {
 command: "uno",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  db.uno[jid]??={startedAt:Date.now(),players:[]};if(!db.uno[jid].players.includes(sender))db.uno[jid].players.push(sender);await save();return reply(`🎴 Juego UNO iniciado. Jugadores: ${db.uno[jid].players.length}.`);
 }
};
