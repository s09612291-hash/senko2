export default {
 command: "steal",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const target=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];if(!target||target===sender)return reply('Menciona a otro usuario.');const {ensureUser}=await import('../../lib/database.js');const other=ensureUser(target);if(Math.random()<.5&&other.coins>0){const n=Math.min(other.coins,Math.floor(Math.random()*101)+50);other.coins-=n;user.coins+=n;await save();return reply(`✦ Robo exitoso: ${n} ${bot.botCurrency}.`)}const loss=Math.min(user.coins,50);user.coins-=loss;await save();return reply(`✐ Te descubrieron y perdiste ${loss} ${bot.botCurrency}.`);
 }
};
