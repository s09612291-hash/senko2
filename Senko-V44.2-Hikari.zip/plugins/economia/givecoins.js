export default {
 command: "givecoins",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const target=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];const n=Math.floor(Number(args.find(x=>/^\d+$/.test(x))));if(!target||!n||n<=0||n>user.coins)return reply('Menciona a un usuario y especifica una cantidad válida.');const {ensureUser}=await import('../../lib/database.js');user.coins-=n;ensureUser(target).coins+=n;await save();return reply(`✦ Transferiste ${n} ${bot.botCurrency} a @${target.split('@')[0]}.`);
 }
};
