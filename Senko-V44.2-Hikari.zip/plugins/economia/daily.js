export default {
 command: "daily",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const now=Date.now();if(now-(user.lastDaily||0)<86400000)return reply('✐ Ya reclamaste tu recompensa diaria. Vuelve después de 24 horas.');user.coins+=500;user.racha=(user.racha||0)+1;user.lastDaily=now;await save();return reply(`¡Recompensa diaria! ✨\nRecibiste 500 ${bot.botCurrency}\nBalance: ${user.coins}\nRacha: ${user.racha}`);
 }
};
