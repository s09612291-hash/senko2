export default {
 command: "work",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const amount=Math.floor(Math.random()*401)+100;if(Math.random()<.1){const loss=Math.floor(Math.random()*101)+50;user.coins=Math.max(0,user.coins-loss);await save();return reply(`Te despidieron y perdiste ${loss} ${bot.botCurrency}.`)}user.coins+=amount;await save();return reply(`Trabajaste como ${['programador','albañil','streamer','repartidor'][Math.floor(Math.random()*4)]} y ganaste ${amount} ${bot.botCurrency}.`);
 }
};
