export default {
 command: "economyboard",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const top=Object.entries(db.users).sort((a,b)=>(b[1].coins+b[1].bank)-(a[1].coins+a[1].bank)).slice(0,10);return reply('🏆 Top Economía\n'+top.map(([id,u],i)=>`${i+1}. @${id.split('@')[0]} — ${u.coins+u.bank} ${bot.botCurrency}`).join('\n'));
 }
};
