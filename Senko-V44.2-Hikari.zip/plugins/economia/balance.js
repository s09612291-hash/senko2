export default {
 command: "balance",
 aliases: ["bal"],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const target=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]||sender;const u=(await import('../../lib/database.js')).ensureUser(target);return reply(`💰 Economía de @${target.split('@')[0]}\nCoins: ${u.coins} ${bot.botCurrency}\nBanco: ${u.bank} ${bot.botCurrency}\nTotal: ${u.coins+u.bank} ${bot.botCurrency}`);
 }
};
