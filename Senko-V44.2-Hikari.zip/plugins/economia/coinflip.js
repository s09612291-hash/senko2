export default {
 command: "coinflip",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const win=Math.random()<.5;const n=Math.floor(Math.random()*101)+50;if(win)user.coins+=n;else user.coins=Math.max(0,user.coins-n);await save();return reply(`🪙 ${Math.random()<.5?'Cara':'Cruz'}\n${win?'Ganaste':'Perdiste'} ${n} ${bot.botCurrency}. Balance: ${user.coins}`);
 }
};
