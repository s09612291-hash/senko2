export default {
 command: "deposit",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const n=Math.floor(Number(args[0]));if(!Number.isFinite(n)||n<=0||n>user.coins)return reply('✐ Indica una cantidad válida disponible en tu balance.');user.coins-=n;user.bank+=n;await save();return reply(`✦ Depositaste ${n} ${bot.botCurrency}. Banco: ${user.bank}`);
 }
};
