export default {
 command: "ytsearch",
 aliases: ["yts"],
 subOnly: true,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const query=args.join(' ');if(!query)return reply('✐ Escribe qué quieres buscar en YouTube.');try{const r=await axios.get('https://hikariapi.skyultraweb.com/api/search/youtube',{params:{q:query},timeout:15000});const arr=r.data?.result||r.data?.results||r.data?.data||[];return reply(`🔎 Resultados YouTube para "${query}"\n${arr.slice(0,8).map((v,i)=>`${i+1}. ${v.title||'Sin título'}\n${v.url||v.link||''} ${v.duration||''}`).join('\\n\\n')||'Sin resultados.'}`)}catch{return reply('✐ La búsqueda no está disponible temporalmente.')}
 }
};
