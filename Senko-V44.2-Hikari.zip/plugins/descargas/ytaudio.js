export default {
 command: "ytaudio",
 aliases: ["yta"],
 subOnly: true,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const url=args[0];if(!url||!/^https?:\/\//i.test(url))return reply('✐ Envía un enlace válido.');try{const r=await axios.get('https://hikariapi.skyultraweb.com/api/download/ytmp3',{params:{url},timeout:20000});const d=r.data?.result||r.data?.data||r.data;return reply(`✦ YTAUDIO\nTítulo: ${d.title||d.name||'Archivo'}\n${d.url||d.download||d.link||'La API no devolvió un enlace válido.'}`)}catch{return reply('✐ La API no respondió o el enlace no es compatible.')}
 }
};
