export default {
 command: "ytmp4",
 aliases: [],
 subOnly: true,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const url=args[0];if(!url||!/^https?:\/\//i.test(url))return reply('✐ Envía un enlace válido.');try{const r=await axios.get('https://hikariapi.skyultraweb.com/api/download/ytmp4',{params:{url},timeout:25000});const d=r.data?.result||r.data?.data||r.data;return reply(`🎬 Video solicitado\nTítulo: ${d.title||'Video'}\n${d.url||d.download||d.link||'La API no devolvió un enlace.'}`)}catch{return reply('✐ No se pudo procesar el video.')}
 }
};
