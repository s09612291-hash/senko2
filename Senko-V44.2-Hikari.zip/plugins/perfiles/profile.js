export default {
 command: "profile",
 aliases: ["perfil"],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const target=m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]||sender;const u=db.users[target]||user;const total=u.coins+u.bank;return reply(`╭─ Perfil de @${target.split('@')[0]}\n❀ Descripción » ${u.desc}\n❀ Cumpleaños » ${u.birthday||'Sin definir'}\n❀ Género » ${u.genre||'Sin definir'}\n❀ Experiencia » ${u.exp}\n❀ Nivel » ${u.level}\n❀ Harem » ${(u.harem||[]).length}\n❀ Coins totales » ${total} ${bot.botCurrency}\n❀ Comandos totales » ${u.commands||0}\n╰────────`);
 }
};
