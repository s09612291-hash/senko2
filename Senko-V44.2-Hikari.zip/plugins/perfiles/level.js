export default {
 command: "level",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const level=Math.max(1,user.level||1),need=level*200;return reply(`✦ Nivel ${level}\nExp ${user.exp||0}/${need}\n[${'█'.repeat(Math.min(10,Math.floor((user.exp||0)/need*10)))}${'░'.repeat(10-Math.min(10,Math.floor((user.exp||0)/need*10)))}]`);
 }
};
