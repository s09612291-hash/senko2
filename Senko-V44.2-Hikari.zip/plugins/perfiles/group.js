export default {
 command: "group",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  if(!isGroup)return reply('Solo en grupos.');const md=await sock.groupMetadata(jid);return reply(`✦ Grupo: ${md.subject}\nParticipantes: ${md.participants.length}\nOwner: ${md.owner||'No disponible'}`);
 }
};
