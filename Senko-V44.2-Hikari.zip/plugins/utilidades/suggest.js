export default {
 command: "suggest",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  if(!args.length)return reply('Escribe la sugerencia después del comando.');await sock.sendMessage(`${bot.owner}@s.whatsapp.net`,{text:`Sugerencia de ${sender}: ${args.join(' ')}`}).catch(()=>{});return reply('✦ Tu sugerencia fue enviada al owner.');
 }
};
