export default {
 command: "ping",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const ms=Date.now()-(m.messageTimestamp?Number(m.messageTimestamp)*1000:Date.now());return reply(`Pong! 🏓\nVelocidad ${Math.max(0,ms)}ms\nUptime ${fmt(Date.now()-globalThis.startedAt)}`);
 }
};
