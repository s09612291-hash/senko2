export default {
 command: "menu",
 aliases: [],
 subOnly: false,
 async run(ctx) {
  const {sock,m,jid,sender,text,args,command,prefix,reply,db,user,bot,axios,save,isOwner,isGroup}=ctx;
  const fmt=(ms)=>{const s=Math.floor(ms/1000),d=Math.floor(s/86400),h=Math.floor(s%86400/3600),min=Math.floor(s%3600/60),sec=s%60;return `${d?d+'d ':''}${h}h ${min}m ${sec}s`};
  const totalCommands=globalThis.plugins.size;const totalUsers=Object.keys(db.users).length;const uptime=fmt(Date.now()-globalThis.startedAt);const groups={Economía:['balance','daily','work','crime','coinflip','roulette','deposit','withdraw','givecoins','economyboard','economyinfo','steal'],Gacha:['rollwaifu','claim','harem','waifusboard','charinfo','charimage','serieinfo','sell','trade','buycharacter'],Perfiles:['profile','level','leaderboard','marry','divorce','setgenre','setbirth','setdescription'],Utilidades:['ping','status','setbanner','getpic','invite'],Subbots:['bots','qr','botinfo','codepremium','qrpremium'],Administración:['kick','promote','demote','warn','tagall','open','close','antilink']};const lines=Object.entries(groups).map(([k,v])=>`» ˚୨•(=^●ω●^=)• ⊹ *${k}*\n${v.filter(c=>globalThis.plugins.has(c)).map(c=>prefix+c).join('  ')}`).join('\n\n');const menuText=`¡𝐇𝐨𝐥𝐚! 𝐒𝐨𝐲 Senko (Principal) 🧧✨\nᴀǫᴜɪ ᴛɪᴇɴᴇs ʟᴀ ʟɪsᴛᴀ ᴅᴇ ᴄᴏᴍᴀɴᴅᴏs\n╭┈ ↷\n│ ✐ 𝓓𝓮𝓿𝓮𝓵𝓸𝓹𝓮𝓭 𝓫𝔂 𝙎𝙚𝙣𝙠𝙤 𝙏𝙚𝙖𝙢 🧧\n│ ✐ ꒷ꕤ💎 ᴄᴏᴍᴀɴᴅᴏs: ${totalCommands}\n│ ✐ ꒷ꕤ💎 ᴜsᴜᴀʀɪᴏs: ${totalUsers}\n│ ✐ ꒷ꕤ💎 ᴛɪᴘᴏ: ${bot.botType}\n│ ✐ ꒷ꕤ💎 ᴀᴄᴛɪᴠᴏ: ${uptime}\n│ ${bot.channel}\n╰─────────────────\n\n${lines}\n\nSoporte: ${bot.supportGroup}`;await sock.sendMessage(jid,{image:{url:bot.menuBanner},caption:menuText,contextInfo:{externalAdReply:{title:"Neko's Club · Senko",body:"Made with ❤️ by Senko Team",thumbnailUrl:bot.menuBanner,sourceUrl:bot.channel,mediaType:1}}},{quoted:m});
 }
};
