export default {
 command: "setbanner", aliases: [], subOnly: false,
 async run({sock,m,jid,reply,bot,save}) {
  const { downloadContentFromMessage } = await import('@whiskeysockets/baileys');
  const quoted=m.message?.extendedTextMessage?.contextInfo?.quotedMessage;
  const imageMsg=m.message?.imageMessage||quoted?.imageMessage;
  if(!imageMsg) return reply('✐ Envía o responde a una imagen con #setbanner para cambiar el banner del menú.');
  try {
   const stream=await downloadContentFromMessage(imageMsg,'image'); const chunks=[]; for await(const c of stream) chunks.push(c);
   const buf=Buffer.concat(chunks); const form=new FormData(); form.append('reqtype','fileupload'); form.append('fileToUpload',new Blob([buf],{type:'image/jpeg'}),'senko-banner.jpg');
   const res=await fetch('https://catbox.moe/user/api.php',{method:'POST',body:form}); const url=(await res.text()).trim();
   if(!res.ok || !/^https?:\/\//i.test(url)) return reply('✐ El proveedor de imágenes no aceptó la imagen.');
   bot.menuBanner=url; await save(); return reply(`✦ Banner del menú actualizado correctamente.\n${url}`);
  } catch(e) { return reply('✐ No se pudo subir la imagen. Inténtalo de nuevo más tarde.'); }
 }
};
