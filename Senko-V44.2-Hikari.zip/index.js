import makeWASocket, { useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion } from '@whiskeysockets/baileys';
import pino from 'pino';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import qrcode from 'qrcode';
import { loadDatabase, saveDatabase } from './lib/database.js';
import { loadPlugins } from './lib/loader.js';
import { handleMessage } from './lib/handler.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
globalThis.__dirname = __dirname;
globalThis.db = await loadDatabase();
globalThis.plugins = await loadPlugins(path.join(__dirname, 'plugins'));
globalThis.startedAt = Date.now();
const app = express();
app.get('/', (_req,res)=>res.status(200).send('Senko V44.2 Hikari is running.'));
app.get('/qr', async (_req,res)=> {
  const qr = globalThis.latestQR;
  if (!qr) return res.status(404).send('QR no disponible. Reinicia la sesión o espera a que se genere.');
  res.type('html').send(`<html><body style="font-family:sans-serif;text-align:center;background:#101522;color:#fff"><h2>Senko V44.2 · Vinculación</h2><img style="width:min(90vw,720px)" src="${await qrcode.toDataURL(qr,{width:1200,margin:2})}"><p>Escanea desde WhatsApp → Dispositivos vinculados</p></body></html>`);
});
const port = Number(process.env.PORT || 3000);
app.listen(port, '0.0.0.0', ()=>console.log(`HTTP server on ${port}`));
setInterval(()=>saveDatabase(globalThis.db).catch(console.error), 30_000).unref();

async function startBot() {
 const { state, saveCreds } = await useMultiFileAuthState(path.join(__dirname,'sessions'));
 const { version } = await fetchLatestBaileysVersion();
 const sock = makeWASocket({ version, auth:state, logger:pino({level:'silent'}), printQRInTerminal:true, browser:['Senko V44.2','Chrome','1.0'], syncFullHistory:false });
 sock.ev.on('creds.update', saveCreds);
 sock.ev.on('connection.update', async ({connection,lastDisconnect,qr})=>{
   if(qr) globalThis.latestQR=qr;
   if(connection==='open') { globalThis.latestQR=null; console.log('Senko conectado.'); }
   if(connection==='close') {
     const code=lastDisconnect?.error?.output?.statusCode;
     if(code!==DisconnectReason.loggedOut) setTimeout(startBot,3000);
     else console.error('Sesión cerrada. Borra sessions solo si deseas volver a vincular.');
   }
 });
 sock.ev.on('messages.upsert', async ({messages,type})=>{
   if(type!=='notify') return;
   for(const msg of messages) {
     if(!msg.message || msg.key.fromMe) continue;
     try { await handleMessage(sock,msg); } catch(err) { console.error('message handler:',err); }
   }
 });
}
await startBot();
